package com.capcutpromax.editor;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.VideoView;
import android.widget.Toast;
import android.graphics.Color;

public class MainActivity extends Activity {
    private static final int PICK_VIDEO = 1001;
    private VideoView videoView;
    private TextView selectedFile;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView label(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(8), dp(8), dp(8), dp(8));
        return t;
    }

    private Button action(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        return b;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(13, 15, 24));
        getWindow().setNavigationBarColor(Color.rgb(13, 15, 24));

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(18), dp(16), dp(16));
        page.setBackgroundColor(Color.rgb(13, 15, 24));

        TextView title = label("CAPCUT PRO MAX", 24, Color.WHITE);
        title.setTypeface(null, 1);
        page.addView(title);

        TextView subtitle = label("استوديو المونتاج — أدوات مجانية", 14, Color.rgb(180, 190, 210));
        page.addView(subtitle);

        videoView = new VideoView(this);
        videoView.setBackgroundColor(Color.BLACK);
        page.addView(videoView, new LinearLayout.LayoutParams(-1, 0, 1.0f));

        selectedFile = label("لم يتم اختيار فيديو بعد", 14, Color.WHITE);
        page.addView(selectedFile);

        Button choose = action("＋  اختر فيديو من الهاتف");
        choose.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.setType("video/*");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(intent, PICK_VIDEO);
        });
        page.addView(choose, new LinearLayout.LayoutParams(-1, -2));

        TextView toolsTitle = label("أدوات التحرير", 18, Color.WHITE);
        toolsTitle.setTypeface(null, 1);
        page.addView(toolsTitle);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        Button trim = action("قص الفيديو");
        Button audio = action("الصوت");
        row1.addView(trim, new LinearLayout.LayoutParams(0, -2, 1));
        row1.addView(audio, new LinearLayout.LayoutParams(0, -2, 1));
        page.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        Button text = action("إضافة نص");
        Button effects = action("المؤثرات");
        row2.addView(text, new LinearLayout.LayoutParams(0, -2, 1));
        row2.addView(effects, new LinearLayout.LayoutParams(0, -2, 1));
        page.addView(row2);

        View.OnClickListener comingSoon = v ->
            Toast.makeText(this, "هذه الأداة ضمن المرحلة التالية من التطوير", Toast.LENGTH_SHORT).show();
        trim.setOnClickListener(comingSoon);
        audio.setOnClickListener(comingSoon);
        text.setOnClickListener(comingSoon);
        effects.setOnClickListener(comingSoon);

        Button export = action("تصدير الفيديو — 1080p / 4K");
        export.setOnClickListener(comingSoon);
        page.addView(export, new LinearLayout.LayoutParams(-1, -2));

        TextView note = label("نسخة تأسيسية 0.1 — سيتم تفعيل أدوات التحرير والتصدير تدريجياً", 11,
                Color.rgb(150, 160, 180));
        page.addView(note);

        setContentView(page);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                try {
                    getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {}
                selectedFile.setText("تم اختيار الفيديو بنجاح");
                videoView.setVideoURI(uri);
                videoView.setOnPreparedListener(mp -> {
                    mp.setLooping(true);
                    videoView.start();
                });
            }
        }
    }
}
